package pipe.modules.interfaces;

public interface Cleanable
{
	public void cleanUp();
	public void finish();
}
