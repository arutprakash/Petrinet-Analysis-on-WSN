/**
 * This is a placeholder for a class to be added as part of the
 * support of exponential distributions.
 * 
 * This will be the gui part of the firing counter simulation.
 * 
 * @author David Patterson 
 *
 */

package pipe.modules.iai;

import pipe.modules.interfaces.IModule;

class SimulationFiringCounterDialog
{
	
	protected SimulationFiringCounterDialog( String _moduleName, 
		IModule _parent )
	{
		// nothing here.
	}
}