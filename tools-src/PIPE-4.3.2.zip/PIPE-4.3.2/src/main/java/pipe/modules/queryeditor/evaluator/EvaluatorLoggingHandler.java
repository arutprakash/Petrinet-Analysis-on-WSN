/**
 * 
 */
package pipe.modules.queryeditor.evaluator;

import java.util.logging.Logger;

/**
 * @author dazz
 * 
 */
interface EvaluatorLoggingHandler
{
	public static final String	pipeEvaluator	= "pipe.modules.queryeditor.evaluator";
	public static Logger		logger			= Logger.getLogger(EvaluatorLoggingHandler.pipeEvaluator);

}
