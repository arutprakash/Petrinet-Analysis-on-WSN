package pipe.models.interfaces;

public interface IDestination{

}
