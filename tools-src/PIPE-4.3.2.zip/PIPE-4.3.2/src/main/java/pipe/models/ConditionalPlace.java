package pipe.models;

import java.io.Serializable;

public class ConditionalPlace extends Connectable implements Serializable
{
    public ConditionalPlace(String id, String name)
    {
        super(id, name);
    }
}
