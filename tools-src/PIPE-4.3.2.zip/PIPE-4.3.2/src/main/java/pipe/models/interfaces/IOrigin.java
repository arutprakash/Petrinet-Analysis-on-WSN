package pipe.models.interfaces;

public interface IOrigin{

}
