package pipe.exceptions;

public class MarkingNotIntegerException extends Exception{
	public MarkingNotIntegerException() {
	      super("Weight must be integer.");
	   }

}
