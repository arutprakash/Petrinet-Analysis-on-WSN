/**
 * 
 */
package pipe.common;

/**
 * @author dazz
 * 
 */
public enum AnalysisType
{
	PASSAGETIME, STEADYSTATE, PERFORMANCEQUERY
}
