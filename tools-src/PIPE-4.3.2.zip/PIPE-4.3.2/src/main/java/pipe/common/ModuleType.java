package pipe.common;

public enum ModuleType
{
    tagged, none
}
