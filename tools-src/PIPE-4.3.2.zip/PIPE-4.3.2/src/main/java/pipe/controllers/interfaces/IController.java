package pipe.controllers.interfaces;

public interface IController {
}
