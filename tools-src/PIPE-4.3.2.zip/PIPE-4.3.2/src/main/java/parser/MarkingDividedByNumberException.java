package parser;

public class MarkingDividedByNumberException extends Exception {
	public MarkingDividedByNumberException(){
		super("Marking divided by number");
	}
	
}
